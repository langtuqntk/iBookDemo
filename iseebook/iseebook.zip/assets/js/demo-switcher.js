$(function() {

	var sidebarColors = "sidebar-default sidebar-inverse sidebar-violet sidebar-green sidebar-info sidebar-midnightblue sidebar-grape sidebar-primary sidebar-alizarin sidebar-indigo navbar-default navbar-inverse navbar-primary navbar-violet navbar-alizarin navbar-grape navbar-danger navbar-green navbar-indigo navbar-info navbar-midnightblue";
	var headerColors = "navbar-default navbar-inverse navbar-primary navbar-violet navbar-alizarin navbar-grape navbar-danger navbar-green navbar-indigo navbar-info navbar-midnightblue";

	//Show Switcher
		$(".demo-options-icon").click(function () {
			$('.demo-options').toggleClass("active");
		});

	//Switch: Fixed Header
		$('input[name="demo-fixedheader"]').on('switchChange.bootstrapSwitch', function(event, state) {
			$('#topnav').toggleClass("navbar-fixed-top navbar-static-top");
			Utility.rightbarTopPos();
		});

	//Switch: Boxed Layout
		$('input[name="demo-boxedlayout"]').on('switchChange.bootstrapSwitch', function(event, state) {
			//close infobar
			if ($('body').hasClass('infobar-active')) $('body').removeClass('infobar-active');


			//change to layout-boxed
			$('body').toggleClass('layout-boxed');
			Utility.autocollapse();

			window.wasOffcanvas = ($('body').hasClass('infobar-offcanvas') || !$('body').hasClass('layout-boxed'));
			if (wasOffcanvas) {
				$('body').toggleClass('infobar-offcanvas infobar-overlay');
			}

			$('.infobar-offcanvas .infobar-wrapper').css('transform', '');

			$('.layout-boxed .infobar-wrapper').css('display', '');

			if (($('body').hasClass('infobar-active')) || ($('body').hasClass('infobar-offcanvas'))) {
				$('.infobar-wrapper').show();
			}

			Utility.rightbarRightPos();
			Utility.rightbarTopPos();

			if (!($('body').hasClass('layout-boxed'))) {
				$('.infobar-wrapper').css('display','');
			}

			//switcher option changes
			$('input[name="demo-collapserightbar"]').bootstrapSwitch('state', false, true);
			$('#demo-boxes').toggleClass('hide');

			//remove bodybg when closed
			$('body:not(.layout-boxed)').css('background','');


		});

	//Switch: Leftbar
		$('input[name="demo-collapseleftbar"]').on('switchChange.bootstrapSwitch', function(event, state) {
			Utility.toggle_leftbar();
		});

	//Switch: Rightbar
		$('input[name="demo-collapserightbar"]').on('switchChange.bootstrapSwitch', function(event, state) {
			Utility.toggle_rightbar();
		});

	//Switch Horizicons
		$('input[name="demo-horizicons"]').on('switchChange.bootstrapSwitch', function(event, state) {
				//if ($('#horizontal-navbar').hasClass('large-icons-nav')) {
					$('#horizontal-navbar').toggleClass('large-icons-nav');
				//}
		});




		//Header Navbar Styles
			$('#demo-header-color span').click(function() {
				if ($(this).hasClass("demo-white")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-default');
					localStorage.setItem('navbar-color','navbar-default');
				}

				if ($(this).hasClass("demo-black")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-inverse');
					localStorage.setItem('navbar-color', 'navbar-inverse');
				}

				if ($(this).hasClass("demo-primary")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-primary');
					localStorage.setItem('navbar-color', 'navbar-primary');
				}

				if ($(this).hasClass("demo-grape")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-grape');
					localStorage.setItem('navbar-color', 'navbar-grape');
				}

				if ($(this).hasClass("demo-green")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-green');
					localStorage.setItem('navbar-color', 'navbar-green');
				}

				if ($(this).hasClass("demo-alizarin")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-alizarin');
					localStorage.setItem('navbar-color', 'navbar-alizarin');
				}

				if ($(this).hasClass("demo-danger")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-danger');
					localStorage.setItem('navbar-color', 'navbar-danger');
				}

				if ($(this).hasClass("demo-indigo")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-indigo');
					localStorage.setItem('navbar-color', 'navbar-indigo');
				}

				if ($(this).hasClass("demo-violet")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-violet');
					localStorage.setItem('navbar-color', 'navbar-violet');
				}

				if ($(this).hasClass("demo-info")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-info');
					localStorage.setItem('navbar-color', 'navbar-info');
				}

				if ($(this).hasClass("demo-midnightblue")) {
					$('#topnav').removeClass(headerColors).addClass('navbar-midnightblue');
					localStorage.setItem('navbar-color', 'navbar-midnightblue');
				}
			});

		//Sidebar Navbar Styles
			$('#demo-sidebar-color span').click(function() {
				if ($(this).hasClass("demo-white")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-default');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-default');

					localStorage.setItem('sidebar-color',"default");
				}

				if ($(this).hasClass("demo-black")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-inverse');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-inverse');

					localStorage.setItem('sidebar-color',"inverse");
				}

				if ($(this).hasClass("demo-midnightblue")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-midnightblue');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-midnightblue');

					localStorage.setItem('sidebar-color',"midnightblue");
				}

				if ($(this).hasClass("demo-grape")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-grape');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-grape');

					localStorage.setItem('sidebar-color',"grape");
				}

				if ($(this).hasClass("demo-green")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-green');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-green');

					localStorage.setItem('sidebar-color',"green");
				}

				if ($(this).hasClass("demo-info")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-info');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-info');

					localStorage.setItem('sidebar-color',"info");
				}

				if ($(this).hasClass("demo-primary")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-primary');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-primary');

					localStorage.setItem('sidebar-color',"primary");
				}

				if ($(this).hasClass("demo-alizarin")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-alizarin');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-alizarin');

					localStorage.setItem('sidebar-color',"alizarin");
				}

				if ($(this).hasClass("demo-indigo")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-indigo');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-indigo');

					localStorage.setItem('sidebar-color',"indigo");
				}

				if ($(this).hasClass("demo-violet")) {
					$('.static-sidebar-wrapper, .fixed-sidebar-wrapper').removeClass(sidebarColors).addClass('sidebar-violet');
					$('#wrapper>nav.navbar').removeClass(sidebarColors).addClass('navbar-violet');

					localStorage.setItem('sidebar-color',"violet");
				}
			});

		//Boxed Backgrounds
			$('#demo-boxed-bg span').click(function() {
				$('body.layout-boxed').css('background', $(this).css('background'));
			});

		//Fixed Header

			$('#demo-fixedheader').click(function () {
				$('body>header.navbar').toggleClass('navbar-fixed-top navbar-static-top')
			})

		//Reset to default style
			$('.demo-reset').click(function () {
				if (!($('header.navbar').hasClass('navbar-inverse'))) {
					$('header.navbar').addClass('navbar-inverse');
				}
			});
});